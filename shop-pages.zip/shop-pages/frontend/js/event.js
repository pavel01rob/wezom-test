let btn = document.querySelector('#btn');
let add = document.querySelector('.add');

btn.onclick = function(){
    add.style.display = 'block';
}